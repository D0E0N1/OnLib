var searchData=
[
  ['addbooktolibrary_0',['addBookToLibrary',['../class_client.html#a2dabdb782ab50fb071e3a5b74ee6d6eb',1,'Client::addBookToLibrary()'],['../classdatabase.html#a85fb3ea15b9a7db44aeef8dcb6edf26a',1,'database::addBookToLibrary()']]],
  ['applytheme_1',['applyTheme',['../main_8cpp.html#a7d24d0c1f2058014f103e48e02f15cbb',1,'applyTheme(bool useDark):&#160;main.cpp'],['../mainwindow_8cpp.html#a7d24d0c1f2058014f103e48e02f15cbb',1,'applyTheme(bool useDark):&#160;main.cpp']]],
  ['assignbook_2',['assignBook',['../class_client.html#ad51e2540d46c944509fb4751a41b6651',1,'Client']]],
  ['assignbooktouser_3',['assignBookToUser',['../classdatabase.html#ac3028a0db4faf3d07e6c855ed0415a1c',1,'database']]],
  ['authenticateuser_4',['authenticateUser',['../classdatabase.html#a7b47abad6ad37bb5376b01a2e369ef7e',1,'database']]]
];
