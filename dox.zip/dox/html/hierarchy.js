var hierarchy =
[
    [ "CommandHandler", "class_command_handler.html", null ],
    [ "database", "classdatabase.html", null ],
    [ "database_destroyer", "classdatabase__destroyer.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "Client", "class_client.html", null ],
      [ "MyTcpServer", "class_my_tcp_server.html", null ]
    ] ]
];