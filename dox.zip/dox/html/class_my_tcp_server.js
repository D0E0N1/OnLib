var class_my_tcp_server =
[
    [ "MyTcpServer", "class_my_tcp_server.html#acf367c4695b4d160c7a2d25c2afaaec4", null ],
    [ "~MyTcpServer", "class_my_tcp_server.html#ab39e651ff7c37c152215c02c225e79ef", null ],
    [ "slotClientDisconnected", "class_my_tcp_server.html#a3e040c49dbefd65b9a58ab662fc9f7a2", null ],
    [ "slotNewConnection", "class_my_tcp_server.html#a0ba7316ffe1a26c57fabde9e74b6c8dc", null ],
    [ "slotServerRead", "class_my_tcp_server.html#ab4a64d2eab985d723090963f5c8a2882", null ],
    [ "mClientRoles", "class_my_tcp_server.html#af162a5686155e3273d54a43b8f624710", null ],
    [ "mClients", "class_my_tcp_server.html#a216504792add53b87f14b76fef9ca5f7", null ],
    [ "mClientUserIds", "class_my_tcp_server.html#a7c69a6a155ce5c46522d5075b2d6be0b", null ],
    [ "mCommandHandler", "class_my_tcp_server.html#ac0ffd85c0cb038bc904ab5bb528bbb0a", null ],
    [ "mTcpServer", "class_my_tcp_server.html#a7d854875e1e02887023ec9aac1a1542c", null ],
    [ "mTcpSocket", "class_my_tcp_server.html#ab55c030e6eb6cf5d1acfe6d7d2bf0ed1", null ]
];