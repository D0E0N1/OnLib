var searchData=
[
  ['database_5fdestroyer_0',['database_destroyer',['../classdatabase.html#a44fb6333d80e1d4e08ca5bba4483f5f3',1,'database']]]
];
