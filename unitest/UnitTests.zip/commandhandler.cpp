#include "commandhandler.h"
#include "database.h"
#include <QDebug>
#include <QCryptographicHash> // Добавить для хеширования пароля
#include <QRandomGenerator>   // Добавить для генерации случайного пароля
#include <QRegularExpression> // Добавить для валидации Email

CommandHandler::CommandHandler() {}
QString CommandHandler::handleRequest(const QString& command,
                                      const QStringList& parts,
                                      const QString& clientRole,
                                      int clientUserId)
{
    try {
        // Общие команды
        if (command == "auth") {
            return handleAuth(parts);
        } else if (command == "reg") {
            return handleReg(parts);
        }

        // Проверка аутентификации для остальных команд
        if (clientUserId == -1) {
            return "error&Authentication required\r\n";
        }
        // Обработка новой команды поиска книг
        // ★ Добавляем обработку НОВЫХ команд перед другими
        if (command == "get_book_annotation") {
            return handleGetBookAnnotation(parts);
        }else if (command == "get_genres_list") {
            // Получение списка жанров может быть доступно и клиенту? Решим, что да.
            // Проверка роли библиотекаря здесь не нужна.
            return handleGetGenresList(parts);
        }else if (command == "update_book_annotation") {
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            return handleUpdateBookAnnotation(parts);
        }else if (command == "import_books_csv") {
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            if (clientUserId == -1) return "error&Authentication required\r\n"; // Доп. проверка
            return handleImportBooksCsv(parts);
        } else if (command == "export_books_csv") {
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            if (clientUserId == -1) return "error&Authentication required\r\n";
            return handleExportBooksCsv(parts);
        }
        else if (command == "search_books") {
            return handleSearchBooks(parts);
        }else if (command == "get_rental_history") {
            if (clientUserId == -1) return "error&Authentication required\r\n";
            // Дополнительная проверка, что запрашивают свою историю
            if (parts.size() == 2) {
                bool ok;
                int requestedUserId = parts.at(1).toInt(&ok);
                if (ok && requestedUserId == clientUserId) {
                    return handleGetRentalHistory(parts);
                } else {
                    qWarning() << "Security Alert: User" << clientUserId << "attempted to access history for user" << parts.value(1);
                    return "error&Access denied\r\n"; // Запрет просмотра чужой истории
                }
            } else {
                return "error&Invalid parameters for get_rental_history (expected user_id)\r\n";
            }
        } else if (command == "get_library_stats") {
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            if (clientUserId == -1) return "error&Authentication required\r\n";
            return handleGetLibraryStats(parts);
        } // Новый обработчик ДЕТАЛЬНОЙ статистики
        else if (command == "get_statistics_report"){
            return handleGetStatisticsReport(parts);
        }else if (command == "get_all_users") {
            // Проверка аутентификации И роли здесь
            if (clientUserId == -1) return "error&Authentication required\r\n";
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            return handleGetAllUsers(parts); // Вызов нового обработчика
        }
        // Команды пользователя
        else if (command == "extend_rental") {
            if (parts.size() != 4) return "error&Invalid parameters\r\n";
            int requestedUserId = parts[1].toInt();

            // Пользователь может продлевать только свои аренды
            if (clientRole != "librarian" && requestedUserId != clientUserId) {
                return "error&Access denied\r\n";
            }
            return handleExtendRental(parts);

        } else if (command == "view_book_stats") {
            if (parts.size() != 2) return "error&Invalid parameters\r\n";
            int requestedUserId = parts[1].toInt();

            if (clientRole != "librarian" && requestedUserId != clientUserId) {
                return "error&Access denied\r\n";
            }
            return handleViewBookStats(parts);

        } else if (command == "view_user_info") {
            if (parts.size() != 2) return "error&Invalid parameters\r\n";
            int requestedUserId = parts[1].toInt();

            // Только библиотекари могут смотреть чужие данные
            if (clientRole != "librarian" && requestedUserId != clientUserId) {
                return "error&Access denied\r\n";
            }
            return handleViewUserInfo(parts);

            // Команды библиотекаря
        } else if (command == "assign_book") {
            if (clientRole != "librarian")
                return "error&Permission denied\r\n";
            return handleAssignBook(parts);

        } else if (command == "unassign_book") {
            if (clientRole != "librarian")
                return "error&Permission denied\r\n";
            return handleUnassignBook(parts);

        } else if (command == "view_user_debts") {
            if (clientRole != "librarian")
                return "error&Permission denied\r\n";
            return handleViewUserDebts(parts);

        } else if (command == "get_user_info") {
            if (clientRole != "librarian")
                return "error&Permission denied\r\n";
            return handleGetUserInfo(parts);

        } else if (command == "add_book_to_lib") {
            if (clientRole != "librarian")
                return "error&Permission denied\r\n";
            return handleAddBookToLibrary(parts);

        } else if (command == "update_book_info") {
            if (clientRole != "librarian")
                return "error&Permission denied\r\n";
            return handleUpdateBookInfo(parts);

        } else if (command == "get_all_books") {
            database& db = database::get_instance();
            QStringList books = db.getAllBooks();
            return QString("books_list+&%1\r\n").arg(books.join("|"));

        } else if (command == "get_all_debts") {
            if (clientRole != "librarian")
                return "error&Permission denied\r\n";
            database& db = database::get_instance();
            QStringList debts = db.getAllDebts();
            return QString("all_debts+&%1\r\n").arg(debts.join("|"));
        } else if (command == "block_user") {
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            return handleBlockUser(parts);
        } else if (command == "unblock_user") {
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            return handleUnblockUser(parts);
        } else if (command == "reset_user_password") {
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            return handleResetUserPassword(parts);
        } else if (command == "update_user_email") {
            if (clientRole != "librarian") return "error&Permission denied\r\n";
            return handleUpdateUserEmail(parts);
        }

        else { // Добавь этот else
            qWarning() << "Unknown command received:" << command; // Для отладки добавь лог
            return "error&Unknown command\r\n";
        }
    }
    catch (const std::exception& e) {
        qCritical() << "Error handling request:" << e.what();
        return "error&Server error\r\n";
    }
}

// Реализация нового обработчика поиска книг
QString CommandHandler::handleSearchBooks(const QStringList& parts) {
    if (parts.size() == 3) { // Ожидаем: search_books & criteria & searchTerm
        QString criteria = parts[1].trimmed();
        QString searchTerm = parts[2].trimmed();

        // Проверка валидности критерия (можно сделать строже)
        if (criteria != "title" && criteria != "author" && criteria != "genre") {
            return "error&Invalid search criteria\r\n";
        }
        if (searchTerm.isEmpty()) {
            return "error&Search term cannot be empty\r\n";
        }


        database& db = database::get_instance();
        QStringList books = db.searchBooks(criteria, searchTerm);

        // Используем тот же формат ответа, что и get_all_books,
        // чтобы клиент мог использовать один и тот же обработчик.
        return QString("books_list+&%1\r\n").arg(books.join("|"));
    }
    qDebug() << "Invalid search request parts:" << parts;
    return "error&Invalid parameters for search\r\n";
}

// User commands
QString CommandHandler::handleExtendRental(const QStringList& parts) {
    if (parts.size() == 4) {
        int user_id = parts[1].toInt();
        int book_id = parts[2].toInt();
        int days = parts[3].toInt();

        qDebug() << "Extend rental request: user" << user_id
                 << "book" << book_id
                 << "days" << days;

        database& db = database::get_instance();
        bool success = db.extendRental(user_id, book_id, days);

        if (success) {
            qDebug() << "Extend successful";
            return QString("extend_rental+&%1&%2\r\n").arg(user_id).arg(book_id);
        }
    }
    qDebug() << "Extend failed - invalid request or DB error";
    return "extend_rental-\r\n";
}

QString CommandHandler::handleViewBookStats(const QStringList& parts) {
    if (parts.size() == 2) {
        int user_id = parts[1].toInt();
        database& db = database::get_instance();
        QString stats = db.getUserBooksStats(user_id);
        if (!stats.isEmpty()) {
            return QString("book_stats+&%1\r\n").arg(stats);
        }
    }
    return "book_stats-\r\n";
}

QString CommandHandler::handleViewUserInfo(const QStringList& parts) {
    if (parts.size() == 2) {
        int user_id = parts[1].toInt();
        database& db = database::get_instance();
        QString info = db.getUserFullInfoById(user_id);
        if (!info.isEmpty()) {
            return QString("user_info+&%1\r\n").arg(info);
            // Формат ответа: login,email,password
        }
    }
    return "user_info-\r\n";
}


// Librarian commands
QString CommandHandler::handleAssignBook(const QStringList& parts) {
    if (parts.size() == 3) {
        int user_id = parts[1].toInt();
        int book_id = parts[2].toInt();
        database& db = database::get_instance();
        if (db.assignBookToUser(user_id, book_id)) {
            return QString("assign_book+&%1&%2\r\n").arg(user_id).arg(book_id);
        }
    }
    return "assign_book-\r\n";
}

QString CommandHandler::handleUnassignBook(const QStringList& parts) {
    if (parts.size() == 3) {
        int user_id = parts[1].toInt();
        int book_id = parts[2].toInt();
        database& db = database::get_instance();
        if (db.unassignBookFromUser(user_id, book_id)) {
            return QString("unassign_book+&%1&%2\r\n").arg(user_id).arg(book_id);
        }
    }
    return "unassign_book-\r\n";
}

QString CommandHandler::handleViewUserDebts(const QStringList& parts) {
    if (parts.size() >= 2) {
        int user_id = parts[1].toInt();
        database& db = database::get_instance();
        QStringList debts = db.getUserDebts(user_id); // Было QString -> QStringList

        if (debts.isEmpty()) {
            return "user_rentals+&No active rentals\r\n";
        } else {
            return QString("user_rentals+&%1\r\n").arg(debts.join("|"));
        }
    }
    return "user_rentals-\r\n";
}

QString CommandHandler::handleGetUserInfo(const QStringList& parts) {
    if (parts.size() == 2) {
        QString login = parts[1].trimmed();
        database& db = database::get_instance();
        QString info = db.getUserPublicInfo(login);
        if (!info.isEmpty()) {
            return QString("public_user_info+&%1\r\n").arg(info);
        }
    }
    return "public_user_info-\r\n";
}

QString CommandHandler::handleAddBookToLibrary(const QStringList& parts) {
    if (parts.size() == 5) {
        QString title = parts[1].trimmed();
        QString author = parts[2].trimmed();
        QString year = parts[3].trimmed();
        QString genre = parts[4].trimmed();
        database& db = database::get_instance();
        if (db.addBookToLibrary(title, author, year, genre)) {
            return QString("add_book_lib+&%1\r\n").arg(title);
        }
    }
    return "add_book_lib-\r\n";
}

QString CommandHandler::handleUpdateBookInfo(const QStringList& parts) {
    if (parts.size() == 6) {
        int book_id = parts[1].toInt();
        QString title = parts[2].trimmed();
        QString author = parts[3].trimmed();
        QString year = parts[4].trimmed();
        QString genre = parts[5].trimmed();
        database& db = database::get_instance();
        if (db.updateBookInfo(book_id, title, author, year, genre)) {
            return QString("update_book+&%1\r\n").arg(book_id);
        }
    }
    return "update_book-\r\n";
}

// Common commands
QString CommandHandler::handleAuth(const QStringList& parts) {
    if (parts.size() == 3) {
        QString login = parts[1].trimmed();
        QString password = parts[2].trimmed();
        database& db = database::get_instance();

        if (db.authenticateUser(login, password)) {
            QString role = db.getUserRole(login);
            int user_id = db.getUserID(login);
            return QString("auth+&%1&%2&%3\r\n")
                .arg(login)
                .arg(role)
                .arg(user_id);
        }
    }
    return "auth-\r\n";
}

QString CommandHandler::handleReg(const QStringList& parts) {
    if (parts.size() == 5) {
        QString login = parts[1].trimmed();
        QString password = parts[2].trimmed();
        QString email = parts[3].trimmed();
        QString role = parts[4].trimmed();
        database& db = database::get_instance();
        if (db.registerUser(login, password, email, role)) {
            return QString("reg+&%1\r\n").arg(login);
        }
    }
    return "reg-\r\n";
}

// Реализация обработчика получения аннотации
QString CommandHandler::handleGetBookAnnotation(const QStringList& parts) {
    if (parts.size() == 2) { // Ожидаем: get_book_annotation & book_id
        bool ok;
        int book_id = parts[1].toInt(&ok);
        if (!ok || book_id <= 0) {
            return "error&Invalid book ID format\r\n";
        }

        database& db = database::get_instance();
        QString title_annotation = db.getBookAnnotation(book_id);

        if (!title_annotation.isNull()) {
            QStringList dataParts = title_annotation.split(":::");
            QString title = dataParts.value(0);
            QString annotation = dataParts.value(1);
            // ★ ВОЗВРАЩАЕМ И ID КНИГИ ★
            return QString("annotation+&%1&%2&%3\r\n").arg(book_id).arg(title).arg(annotation);
        } else {
            return "annotation-&Book not found\r\n";
        }
    }
    return "error&Invalid parameters for get_book_annotation\r\n";
}

// Реализация обработчика обновления аннотации
QString CommandHandler::handleUpdateBookAnnotation(const QStringList& parts) {
    if (parts.size() == 3) { // Ожидаем: update_book_annotation & book_id & annotation_text
        bool ok;
        int book_id = parts[1].toInt(&ok);
        if (!ok || book_id <= 0) {
            return "error&Invalid book ID format\r\n";
        }
        QString annotation = parts[2]; // Аннотацию не trim-мим

        database& db = database::get_instance();
        if (db.updateBookAnnotation(book_id, annotation)) {
            return QString("update_annotation+&%1\r\n").arg(book_id); // Ответ: update_annotation+&book_id
        } else {
            // Пытаемся определить причину ошибки
            if (!db.userExists(book_id)) { // Это плохая проверка, нужно проверять книги! Переделать.
                // Правильно: Добавить метод db.bookExists(book_id)
                return "update_annotation-&Book not found\r\n";
            } else {
                return "update_annotation-&Failed to update annotation in DB\r\n";
            }
        }
    }
    return "error&Invalid parameters for update_book_annotation\r\n";
}

// Реализация обработчика получения списка пользователей ★
QString CommandHandler::handleGetAllUsers(const QStringList& parts) {
    // parts здесь не используется, но сигнатура стандартная
    Q_UNUSED(parts);

    database& db = database::get_instance();
    QStringList users = db.getAllUsers();

    // Формат ответа: all_users+&id1,login1|id2,login2|...
    return QString("all_users+&%1\r\n").arg(users.join("|"));
}

QString escapeCsvField(const QString& field) {
    // Если поле содержит запятую, кавычку или символ новой строки, заключаем в кавычки
    if (field.contains(',') || field.contains('"') || field.contains('\n') || field.contains('\r')) {
        QString escapedField = field;
        // Удваиваем внутренние кавычки
        escapedField.replace("\"", "\"\"");
        return "\"" + escapedField + "\"";
    }
    // Иначе возвращаем поле как есть
    return field;
}

// Обработчик ЭКСПОРТА книг в CSV
QString CommandHandler::handleExportBooksCsv(const QStringList& parts) {
    Q_UNUSED(parts); // Параметры пока не используются
    qDebug() << "Handling export_books_csv request";

    database& db = database::get_instance();
    // Получаем данные всех книг (метод должен возвращать и аннотацию!)
    QStringList booksData = db.getAllBooks();

    QString csvContent = "Title,Author,Year,Genre,Annotation\r\n"; // Заголовок CSV

    for (const QString& bookEntry : booksData) {
        QStringList bookParts = bookEntry.split(',');
        if (bookParts.size() < 7) { // Ожидаем ID, Title, Author, Year, Genre, Available, Annotation
            qWarning() << "Skipping invalid book entry during CSV export:" << bookEntry;
            continue;
        }

        // Экранируем поля перед добавлением
        QString title = escapeCsvField(bookParts.value(1));
        QString author = escapeCsvField(bookParts.value(2));
        QString year = escapeCsvField(bookParts.value(3));
        QString genre = escapeCsvField(bookParts.value(4));
        QString annotation = escapeCsvField(bookParts.value(6)); // Аннотация - 7-й элемент (индекс 6)

        csvContent += QString("%1,%2,%3,%4,%5\r\n")
                          .arg(title, author, year, genre, annotation);
    }

    // Формат ответа: export_books+&<csv_содержимое>
    // Важно: убедиться, что сам csvContent не содержит '&', иначе разбор на клиенте сломается!
    // Если '&' может быть в данных, нужно менять разделитель команд или использовать base64.
    // Пока предполагаем, что '&' в данных нет.
    return QString("export_books+&%1\r\n").arg(csvContent);
}


// Обработчик ИМПОРТА книг из CSV
QString CommandHandler::handleImportBooksCsv(const QStringList& parts) {
    qDebug() << "Handling import_books_csv request";
    if (parts.size() < 2) {
        return "error&No CSV data provided for import\r\n";
    }

    // Объединяем все части, начиная со второй, на случай если данные содержали '&'
    // (Хотя лучше было бы передавать данные в Base64 или через POST, но для простоты...)
    QString csvData = parts.mid(1).join('&'); // <- Не очень надежно, если & есть в данных!

    database& db = database::get_instance();
    QStringList lines = csvData.split('\n', Qt::SkipEmptyParts); // Разделяем на строки, пропускаем пустые

    if (lines.size() <= 1) { // Должен быть хотя бы заголовок и одна строка данных
        return "error&CSV data is empty or contains only header\r\n";
    }

    // Проверяем заголовок (опционально, но полезно)
    QString header = lines.first().trimmed().toLower();
    if (!header.startsWith("title,author,year,genre")) {
        qWarning() << "CSV Import: Invalid or missing header. Expected 'Title,Author,Year,Genre,...'. Got:" << lines.first().trimmed();
        // Можно вернуть ошибку, но попробуем обработать без заголовка
        // return "error&Invalid CSV header\r\n";
        // lines.removeFirst(); // Если решаем НЕ ТРЕБОВАТЬ заголовок
    } else {
        lines.removeFirst(); // Удаляем заголовок из списка для обработки
    }


    int successCount = 0;
    int failCount = 0;
    QStringList errorDetails;

    for (int i = 0; i < lines.size(); ++i) {
        QString line = lines[i].trimmed();
        if (line.isEmpty()) continue;

        // Очень простой парсинг CSV, НЕ учитывает кавычки и запятые внутри полей!
        // Для реального приложения нужна библиотека или более сложный парсер.
        QStringList fields = line.split(',');

        // Ожидаем минимум 4 поля (Title, Author, Year, Genre). Аннотация опциональна.
        if (fields.size() < 4) {
            failCount++;
            errorDetails << QString("Line %1: Invalid column count (%2, expected at least 4)").arg(i + 2).arg(fields.size());
            continue;
        }

        QString title = fields.value(0).trimmed();
        QString author = fields.value(1).trimmed();
        QString year = fields.value(2).trimmed();
        QString genre = fields.value(3).trimmed();
        QString annotation = (fields.size() > 4) ? fields.value(4).trimmed() : ""; // Аннотация опциональна

        // Простая валидация
        if (title.isEmpty() || author.isEmpty() || year.isEmpty() || genre.isEmpty()) {
            failCount++;
            errorDetails << QString("Line %1: Missing required field(s) (Title, Author, Year, Genre)").arg(i + 2);
            continue;
        }
        bool yearOk; year.toInt(&yearOk);
        if (!yearOk) {
            failCount++;
            errorDetails << QString("Line %1: Invalid year format (%2)").arg(i + 2).arg(year);
            continue;
        }

        // Добавляем книгу в БД
        if (db.addBookToLibrary(title, author, year, genre/*, annotation*/)) { // Нужно передать и аннотацию, если addBookToLibrary ее поддерживает
            // Нужно модифицировать addBookToLibrary для приёма аннотации!
            // Пока передаем без неё.
            successCount++;
        } else {
            failCount++;
            // Можно попытаться получить более детальную ошибку из БД, но для простоты:
            errorDetails << QString("Line %1: Failed to add book to DB (maybe duplicate?) Title: %2").arg(i + 2).arg(title);
        }
    }

    // Формируем ответ-сводку
    QString summary = QString("Import complete. Total lines processed: %1. Successful: %2. Failed: %3.")
                          .arg(lines.size()).arg(successCount).arg(failCount);
    if (!errorDetails.isEmpty()) {
        summary += "\nErrors:\n" + errorDetails.join("\n");
    }

    if (failCount > 0) {
        // Возвращаем частичный успех или ошибку? Давайте вернем "+", но с деталями
        return QString("import_books+&%1\r\n").arg(summary);
    } else {
        return QString("import_books+&%1\r\n").arg(summary);
    }
}

// Блокировка пользователя
QString CommandHandler::handleBlockUser(const QStringList& parts) {
    if (parts.size() != 2) return "error&Invalid parameters for block_user\r\n";
    bool ok;
    int user_id = parts[1].toInt(&ok);
    if (!ok || user_id <= 0) return "error&Invalid user ID format\r\n";

    database& db = database::get_instance();
    if (db.setUserStatus(user_id, "blocked")) {
        return QString("block_user+&%1\r\n").arg(user_id);
    } else {
        // Попытка определить причину (пользователь не найден?)
        return "block_user-&Failed to block user (not found?)\r\n";
    }
}

// Разблокировка пользователя
QString CommandHandler::handleUnblockUser(const QStringList& parts) {
    if (parts.size() != 2) return "error&Invalid parameters for unblock_user\r\n";
    bool ok;
    int user_id = parts[1].toInt(&ok);
    if (!ok || user_id <= 0) return "error&Invalid user ID format\r\n";

    database& db = database::get_instance();
    if (db.setUserStatus(user_id, "active")) {
        return QString("unblock_user+&%1\r\n").arg(user_id);
    } else {
        return "unblock_user-&Failed to unblock user (not found?)\r\n";
    }
}

// Сброс/Установка пароля пользователя Библиотекарем
QString CommandHandler::handleResetUserPassword(const QStringList& parts) {
    if (parts.size() != 3) return "error&Invalid parameters for reset_user_password (expected id&new_password)\r\n";
    bool ok;
    int user_id = parts[1].toInt(&ok);
    if (!ok || user_id <= 0) return "error&Invalid user ID format\r\n";
    QString newPassword = parts[2]; // Пароль от клиента

    // Валидация пароля
    if (newPassword.length() < 8 || newPassword.length() > 12 || !QRegularExpression("^[a-zA-Z0-9!@#$%^&*()_+-=]+$").match(newPassword).hasMatch()) {
        return "reset_password-&New password does not meet requirements (8-12 chars, lat/num/symbols)\r\n";
    }

    database& db = database::get_instance();
    // Передаем ОРИГИНАЛЬНЫЙ ПАРОЛЬ в метод БД
    if (db.resetUserPassword(user_id, newPassword)) {
        qDebug() << "Successfully set new PLAIN TEXT password for user" << user_id;
        return QString("reset_password+&%1&Password successfully set.\r\n").arg(user_id);
    } else {
        return "reset_password-&Failed to set new password (user not found? DB error?)\r\n";
    }
}

// Обновление email пользователя
QString CommandHandler::handleUpdateUserEmail(const QStringList& parts) {
    if (parts.size() != 3) return "error&Invalid parameters for update_user_email (expected id&email)\r\n";
    bool ok;
    int user_id = parts[1].toInt(&ok);
    if (!ok || user_id <= 0) return "error&Invalid user ID format\r\n";
    QString new_email = parts[2].trimmed();

    // Серверная валидация email
    static const QRegularExpression emailRegex("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    if (!emailRegex.match(new_email).hasMatch()) {
        return "error&Invalid email format\r\n";
    }

    database& db = database::get_instance();
    if (db.updateUserEmail(user_id, new_email)) {
        return QString("update_email+&%1\r\n").arg(user_id);
    } else {
        // Пытаемся понять причину: возможно, email уже занят?
        // (updateUserEmail сама проверяет уникальность)
        return "update_email-&Failed to update email (user not found or email taken?)\r\n";
    }
}

// Обработчик запроса истории аренды
QString CommandHandler::handleGetRentalHistory(const QStringList& parts) {
    // Проверку прав (что юзер запрашивает свою историю) уже сделали в handleRequest
    if (parts.size() != 2) return "error&Internal: Invalid parameters in handleGetRentalHistory\r\n"; // Не должно случиться
    bool ok;
    int user_id = parts[1].toInt(&ok);
    if (!ok || user_id <= 0) return "error&Internal: Invalid user ID format in handleGetRentalHistory\r\n"; // Не должно случиться

    database& db = database::get_instance();
    QStringList history = db.getUserRentalHistory(user_id);

    return QString("rental_history+&%1\r\n").arg(history.join("|"));
}

// Обработчик запроса статистики библиотеки
QString CommandHandler::handleGetLibraryStats(const QStringList& parts) {
    Q_UNUSED(parts); // Параметры не нужны

    database& db = database::get_instance();

    int totalBooks = db.getTotalBookCount();
    int availableBooks = db.getAvailableBookCount();
    int rentedBooks = (totalBooks >= 0 && availableBooks >= 0) ? (totalBooks - availableBooks) : -1; // Вычисляем, если данные корректны
    int totalClients = db.getTotalClientCount();
    int activeRentals = db.getActiveRentalCount();
    int overdueRentals = db.getOverdueRentalCount();

    // Проверка на ошибки получения данных (-1)
    if (totalBooks < 0 || availableBooks < 0 || totalClients < 0 || activeRentals < 0 || overdueRentals < 0) {
        return "error&Failed to retrieve some statistics from DB\r\n";
    }

    // Формат ответа: library_stats+&total&available&rented&clients&active_rentals&overdue_rentals
    return QString("library_stats+&%1&%2&%3&%4&%5&%6\r\n")
        .arg(totalBooks)
        .arg(availableBooks)
        .arg(rentedBooks)
        .arg(totalClients)
        .arg(activeRentals)
        .arg(overdueRentals);
}

// Новый обработчик для запроса ДЕТАЛЬНЫХ ОТЧЕТОВ
QString CommandHandler::handleGetStatisticsReport(const QStringList& parts) {
    // Проверка количества параметров (команда уже проверена в handleRequest)
    // Ожидаем: get_statistics_report & reportType & startDate & endDate & optionalFilter
    if (parts.size() != 5) {
        qWarning() << "Invalid parameter count for get_statistics_report. Expected 5, got" << parts.size();
        return "error&Invalid parameters for statistics report (expected 5 parts)\r\n";
    }

    // Извлекаем параметры
    QString reportType = parts[1];
    QString startDateStr = parts[2];
    QString endDateStr = parts[3];
    QString optionalFilter = parts[4]; // Может быть пустой строкой

    // TODO: Добавить более строгую валидацию параметров здесь, если нужно
    // Например, проверить формат дат (хотя SQLite гибок)
    QDate startDate = QDate::fromString(startDateStr, Qt::ISODate);
    QDate endDate = QDate::fromString(endDateStr, Qt::ISODate);
    if (!startDate.isValid() || !endDate.isValid() || startDate > endDate) {
        return "error&Invalid date format or range (yyyy-MM-dd expected, start <= end)\r\n";
    }
    // Валидация reportType? Можно проверить по списку допустимых.
    // Валидация optionalFilter? Зависит от контекста фильтра.

    qDebug() << "Processing statistics report request. Type:" << reportType
             << "Start:" << startDateStr << "End:" << endDateStr << "Filter:" << optionalFilter;

    // Получаем экземпляр базы данных
    database& db = database::get_instance();

    // Вызываем метод БД для получения данных отчета
    QString reportResult = db.getReportData(reportType, startDateStr, endDateStr, optionalFilter);

    // Анализируем результат, полученный от базы данных
    if (reportResult.startsWith("error:")) {
        // Если БД вернула ошибку
        QString errorMsg = reportResult.mid(6); // Убираем префикс "error:"
        qWarning() << "Database error generating report" << reportType << ":" << errorMsg;
        // Формируем ответ об ошибке для клиента
        return QString("report_data-&%1\r\n").arg(errorMsg);
    } else if (reportResult.startsWith("chart:")) {
        // Если БД вернула данные для графика
        // Формат ответа БД: chart:ТипОтчета&Метка1,Метка2&Значение1,Значение2...
        QString chartData = reportResult.mid(6); // Убираем префикс "chart:"
        QStringList chartParts = chartData.split('&'); // Разделяем тип, метки, значения
        if (chartParts.size() == 3) {
            QString responseType = chartParts[0];
            QString labels = chartParts[1];
            QString values = chartParts[2];
            // Формируем ответ для клиента для графика
            return QString("report_chart_data+&%1&%2&%3\r\n").arg(responseType, labels, values);
        } else {
            // Ошибка: некорректный формат данных для графика от БД
            qWarning() << "Invalid chart data format from DB:" << reportResult;
            return "report_data-&Invalid chart data format from database\r\n";
        }
    } else if (reportResult.contains('|')) {
        // Если БД вернула данные для таблицы (содержит разделитель '|')
        // Формат ответа БД: Заголовок1,Заголовок2|Данные11,Данные12|Данные21,Данные22...
        QStringList headerAndData = reportResult.split('|');
        QString headers = headerAndData.takeFirst(); // Первая часть - заголовки
        QString data = headerAndData.join('|');     // Остальные части соединяем обратно - это данные
        // Формируем ответ для клиента для таблицы
        return QString("report_table_data+&%1&%2&%3\r\n").arg(reportType, headers, data);
    } else if (reportResult.isEmpty()) {
        // Если БД вернула пустую строку - значит, данных для отчета нет
        qDebug() << "No data found for report:" << reportType;
        // Отправляем клиенту ответ с пустыми данными, но правильным типом,
        // чтобы он знал, что запрос обработан, но результат пуст.
        // Отправляем как пустую таблицу.
        return QString("report_table_data+&%1&& \r\n").arg(reportType); // Тип, Пустые заголовки, Пустые данные
    } else {
        // Неожиданный формат ответа от БД (не ошибка, не график, не таблица, не пусто)
        qWarning() << "Unknown report data format from DB:" << reportResult;
        return "report_data-&Unknown or invalid report data format received from database\r\n";
    }
}

//  Обработчик запроса списка жанров
QString CommandHandler::handleGetGenresList(const QStringList& parts) {
    // Параметры parts пока не используются
    Q_UNUSED(parts);
    qDebug() << "Processing request for genres list.";

    database& db = database::get_instance();
    QStringList genres = db.getGenres(); // Вызываем метод БД

    if (genres.isEmpty()) {
        qDebug() << "No genres found in the database.";
        // Можно вернуть "+" с пустыми данными, или "-" с сообщением
        // Вернем "+", чтобы клиент корректно обработал пустой список
        return QString("genres_list+&\r\n"); // Команда+, пустая строка данных
    } else {
        qDebug() << "Returning" << genres.count() << "genres.";
        // Формат ответа: genres_list+&жанр1,жанр2,жанр3...
        return QString("genres_list+&%1\r\n").arg(genres.join(','));
    }
    // Обработка ошибок произойдет на уровне db.getGenres() или здесь можно добавить try-catch
}
