var searchData=
[
  ['viewallbooks_0',['viewAllBooks',['../class_client.html#af794d8365645c702216edf80f8b3dfd1',1,'Client']]],
  ['viewbookstats_1',['viewBookStats',['../class_client.html#afc17c5f12a3f00079da9997d6fe0e96b',1,'Client']]],
  ['viewrentalhistory_2',['viewRentalHistory',['../class_client.html#a4376368afb15450fe21613b05d7828d5',1,'Client']]],
  ['viewuserdebts_3',['viewUserDebts',['../class_client.html#ad48c535539035ccc16261e290e048c1b',1,'Client']]],
  ['viewuserinfo_4',['viewUserInfo',['../class_client.html#a288024b7c7f1c58986cf14f9e577e83b',1,'Client']]]
];
