var searchData=
[
  ['p_5finstance_0',['p_instance',['../class_client.html#a2b768fa77948211e40ce05f027363a9f',1,'Client::p_instance'],['../classdatabase__destroyer.html#a79ad0611fc1e876b6eb755a7255150d7',1,'database_destroyer::p_instance'],['../classdatabase.html#a77030a571acb63483493672e2a32fd33',1,'database::p_instance']]],
  ['populatebookstable_1',['populateBooksTable',['../class_main_window.html#ad31cd6ca1214f18a97f40eeeea1b2411',1,'MainWindow']]],
  ['populatehistorytable_2',['populateHistoryTable',['../class_main_window.html#ac59a98930402b8501b123303b7ca6fcc',1,'MainWindow']]],
  ['populateuserstable_3',['populateUsersTable',['../class_main_window.html#a217149a8a5701a9dbc36ea5f5738a8a4',1,'MainWindow']]]
];
