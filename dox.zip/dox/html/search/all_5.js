var searchData=
[
  ['get_5finstance_0',['get_instance',['../class_client.html#a0d1a377ba03116a80a8a85b7f4b61c84',1,'Client::get_instance()'],['../classdatabase.html#ad01404aa671475dc786697f8e30e11e7',1,'database::get_instance()']]],
  ['getallbooks_1',['getAllBooks',['../classdatabase.html#a8928d8c69987d81a073cfa2b5c6b6d5b',1,'database']]],
  ['getallusers_2',['getAllUsers',['../class_client.html#ac391f3496c346dac008d6904d92183e5',1,'Client::getAllUsers()'],['../classdatabase.html#ab8601178b8244082652975b96264aefe',1,'database::getAllUsers()']]],
  ['getbookannotation_3',['getBookAnnotation',['../class_client.html#a1aaf18b5a74df8a24ee001c6c35092a1',1,'Client']]],
  ['getlibrarystats_4',['getLibraryStats',['../class_client.html#aa5e2d6779e472d77a1de46600f70a392',1,'Client']]],
  ['getrole_5',['getRole',['../class_client.html#a461620f65ca44401a4cc9d0aab29bfd9',1,'Client']]],
  ['getselecteduseridfromtable_6',['getSelectedUserIdFromTable',['../class_main_window.html#a8ca8cdb277185701c23b628b6dd69f37',1,'MainWindow']]],
  ['getuserbooksstats_7',['getUserBooksStats',['../classdatabase.html#a2f603c6b1421e580730abe00a023cb53',1,'database']]],
  ['getuserdebts_8',['getUserDebts',['../classdatabase.html#acba38ed8963938713dcd538d34cab802',1,'database']]],
  ['getuserfullinfo_9',['getUserFullInfo',['../classdatabase.html#a405b681f2a99f4c9c03daea7f32e1b0d',1,'database']]],
  ['getuserfullinfobyid_10',['getUserFullInfoById',['../classdatabase.html#ab91ccbae0a7404da6bdfc5f83be59ad0',1,'database']]],
  ['getuserid_11',['getUserID',['../classdatabase.html#a14fd44aa08df7cd26eaa3ac853843001',1,'database']]],
  ['getuserid_12',['getUserId',['../class_client.html#a4647a90891d069e943a06419b07bc256',1,'Client']]],
  ['getuserinfo_13',['getUserInfo',['../class_client.html#aae779cc7863a93713d9337395b3f2b6a',1,'Client']]],
  ['getuserrole_14',['getUserRole',['../classdatabase.html#ae2b78c832dc64aa2745cc3d2f4218ac4',1,'database']]]
];
