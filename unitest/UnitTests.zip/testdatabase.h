#ifndef TESTDATABASE_H
#define TESTDATABASE_H

#include <QtTest>
#include <QObject>


class TestDatabase : public QObject
{
    Q_OBJECT

public:
    TestDatabase();
    ~TestDatabase();

private slots:
    void initTestCase();
    void cleanupTestCase();
    void init();
    void cleanup();

    void testUserRegistrationAndAuthentication();
    void testAddBookAndAnnotation();
    void testSearchBooks();
    void testUserStatusAndBlocking();
};

#endif // TESTDATABASE_H
