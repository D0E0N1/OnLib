var main_8cpp =
[
    [ "applyTheme", "main_8cpp.html#a7d24d0c1f2058014f103e48e02f15cbb", null ],
    [ "main", "main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];