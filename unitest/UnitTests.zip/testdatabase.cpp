#include "testdatabase.h"  // Включаем объявление класса
#include <QCoreApplication>
#include "database.h"
#include <QFile>


TestDatabase::TestDatabase()
{
    // Конструктор
}

TestDatabase::~TestDatabase()
{
    // Деструктор
}

void TestDatabase::initTestCase()
{
    // Эта функция вызывается один раз перед всеми тестами.
    // Мы удалим существующий файл БД, чтобы каждый тестовый запуск начинался с чистого листа.
    // database::get_instance() создаст его заново.
    if (QFile::exists("mydatabase.db")) {
        if (!QFile::remove("mydatabase.db")) {
            qWarning("Could not remove existing mydatabase.db before tests!");
        }
    }
    // Первый вызов get_instance() создаст БД и таблицы.
    // Это также гарантирует, что экземпляр database создан до первого init().
    database::get_instance();
    qDebug() << "TestDatabase: initTestCase - Database prepared for testing.";
}

void TestDatabase::cleanupTestCase()
{
    // Эта функция вызывается один раз после всех тестов.
    qDebug() << "TestDatabase: cleanupTestCase - All tests finished.";
}

void TestDatabase::init()
{
    // Эта функция вызывается перед каждым тестовым методом.
    // Очищаем таблицы для обеспечения независимости тестов.
    database& db = database::get_instance();
    QSqlQuery query(db.my_database); // Используем friend-доступ к my_database

    QStringList tables = {"rental_history", "rentals", "users", "books"};
    for (const QString& tableName : tables) {
        if (!query.exec("DELETE FROM " + tableName)) {
            qWarning() << "Failed to clear table" << tableName << ":" << query.lastError().text();
        }
        // Сброс автоинкрементных счетчиков для SQLite
        if (!query.exec("DELETE FROM sqlite_sequence WHERE name='" + tableName + "'")) {
        }
    }
    qDebug() << "TestDatabase: init - Tables cleared for new test.";
}

void TestDatabase::cleanup()
{
    // Эта функция вызывается после каждого тестового метода.
    qDebug() << "TestDatabase: cleanup - Test method finished.";
}

void TestDatabase::testUserRegistrationAndAuthentication()
{
    database& db = database::get_instance();

    // 1. Успешная регистрация
    QVERIFY2(db.registerUser("testuser1", "Pass123!", "user1@example.com", "client"),
             "User registration should succeed.");

    // 2. Попытка регистрации пользователя с тем же логином (должна провалиться)
    QVERIFY2(!db.registerUser("testuser1", "OtherPass", "user1_alt@example.com", "client"),
             "Registering an existing user should fail.");

    // 3. Успешная аутентификация
    QVERIFY2(db.authenticateUser("testuser1", "Pass123!"),
             "Authentication with correct credentials should succeed.");

    // 4. Аутентификация с неверным паролем
    QVERIFY2(!db.authenticateUser("testuser1", "WrongPass!"),
             "Authentication with incorrect password should fail.");

    // 5. Аутентификация несуществующего пользователя
    QVERIFY2(!db.authenticateUser("nonexistentuser", "Pass123!"),
             "Authentication of a non-existent user should fail.");

    // 6. Проверка роли пользователя
    QCOMPARE(db.getUserRole("testuser1"), QString("client"));

    // 7. Проверка ID пользователя
    int userId = db.getUserID("testuser1");
    QVERIFY2(userId > 0, "User ID should be a positive integer.");
}

void TestDatabase::testUserStatusAndBlocking()
{
    database& db = database::get_instance();
    db.registerUser("blocktestuser", "Pass123!", "block@example.com", "client");
    int userId = db.getUserID("blocktestuser");
    QVERIFY2(userId > 0, "Failed to get ID for blocktestuser.");

    // 1. Проверка начального статуса (должен быть 'active')
    QCOMPARE(db.getUserStatus(userId), QString("active"));
    QVERIFY2(db.authenticateUser("blocktestuser", "Pass123!"), "User should be active and authenticatable initially.");

    // 2. Блокировка пользователя
    QVERIFY2(db.setUserStatus(userId, "blocked"), "setUserStatus to 'blocked' should succeed.");
    QCOMPARE(db.getUserStatus(userId), QString("blocked"));

    // 3. Аутентификация заблокированного пользователя (должна провалиться)
    QVERIFY2(!db.authenticateUser("blocktestuser", "Pass123!"), "Authentication of a blocked user should fail.");

    // 4. Разблокировка пользователя
    QVERIFY2(db.setUserStatus(userId, "active"), "setUserStatus to 'active' should succeed.");
    QCOMPARE(db.getUserStatus(userId), QString("active"));

    // 5. Аутентификация разблокированного пользователя (должна быть успешной)
    QVERIFY2(db.authenticateUser("blocktestuser", "Pass123!"), "Authentication of a re-activated user should succeed.");
}


void TestDatabase::testAddBookAndAnnotation()
{
    database& db = database::get_instance();

    // 1. Добавление книги
    QVERIFY2(db.addBookToLibrary("The Test Book", "Anonymous Coder", "2024", "Tech"),
             "Adding a book should succeed.");

    // 2. Получение всех книг и проверка наличия добавленной
    //    Так как addBookToLibrary не возвращает ID, найдем книгу по названию.
    QStringList books = db.getAllBooks();
    int testBookId = -1;
    bool found = false;
    for (const QString& bookData : books) {
        if (bookData.contains("The Test Book")) {
            testBookId = bookData.split(',').first().toInt(); // ID - первый элемент
            found = true;
            break;
        }
    }
    QVERIFY2(found, "The newly added book was not found in getAllBooks().");
    QVERIFY2(testBookId > 0, "Book ID should be positive.");

    // 3. Обновление аннотации для этой книги
    QString annotation = "This is a detailed annotation for The Test Book.";
    QVERIFY2(db.updateBookAnnotation(testBookId, annotation),
             "Updating book annotation should succeed.");

    // 4. Получение и проверка аннотации
    QString titleAndAnnotation = db.getBookAnnotation(testBookId);
    QVERIFY2(!titleAndAnnotation.isEmpty(), "getBookAnnotation should not return empty for an existing book.");

    QStringList parts = titleAndAnnotation.split(":::");
    QCOMPARE(parts.size(), 2); // Ожидаем "title:::annotation"
    if (parts.size() == 2) {
        QCOMPARE(parts[0], QString("The Test Book")); // Проверка названия
        QCOMPARE(parts[1], annotation);             // Проверка аннотации
    }

    // 5. Попытка получить аннотацию для несуществующей книги
    QVERIFY2(db.getBookAnnotation(99999).isEmpty(), // ID, которого точно нет
             "getBookAnnotation for a non-existent book ID should return empty.");
}

void TestDatabase::testSearchBooks()
{
    database& db = database::get_instance();

    // Добавим несколько книг для теста
    db.addBookToLibrary("Alpha Search", "Author A", "2000", "GenreX");
    db.addBookToLibrary("Beta Test", "Author B", "2001", "GenreY");
    db.addBookToLibrary("Gamma Alpha", "Author C", "2002", "GenreX");
    db.addBookToLibrary("Delta Search", "Author A", "2003", "GenreZ");

    // 1. Поиск по названию (частичное совпадение)
    QStringList results = db.searchBooks("title", "Alpha");
    QCOMPARE(results.size(), 2); // "Alpha Search", "Gamma Alpha"

    // 2. Поиск по автору
    results = db.searchBooks("author", "Author A");
    QCOMPARE(results.size(), 2); // "Alpha Search", "Delta Search"

    // 3. Поиск по жанру
    results = db.searchBooks("genre", "GenreX");
    QCOMPARE(results.size(), 2); // "Alpha Search", "Gamma Alpha"

    // 4. Поиск по названию (точное, но регистронезависимое)
    results = db.searchBooks("title", "beta test");
    QCOMPARE(results.size(), 1);
    if (!results.isEmpty()) {
        QVERIFY(results.first().contains("Beta Test"));
    }

    // 5. Поиск, не дающий результатов
    results = db.searchBooks("title", "NonExistentBook123");
    QVERIFY(results.isEmpty());

    // 6. Поиск с невалидным критерием (должен вернуть пустой список, как реализовано в database.cpp)
    results = db.searchBooks("invalid_criteria", "test");
    QVERIFY(results.isEmpty());
}
