var searchData=
[
  ['importbookscsv_0',['importBooksCsv',['../class_client.html#aaf22fa7a4dd3a703c99f1df348087f9e',1,'Client']]],
  ['initialize_1',['initialize',['../classdatabase__destroyer.html#ac8b7d07c088aab08a11af3446da63fe8',1,'database_destroyer']]],
  ['isbookavailable_2',['isBookAvailable',['../classdatabase.html#a01468ca3fbedd43291572745f210a389',1,'database']]]
];
