#include <QApplication>
#include "mytcpserver.h"
#include "mainwindow.h"
#include <QApplication>
#include <QSettings>
#include <QStyle>
#include <QPalette>
#include <QtTest>
#include "testdatabase.h"
#include <vector> // для std::vector
#include <string> // для std::string
#include <cstring> // для strcmp

// --- Новая функция для применения темы ---
void applyTheme(bool useDark) {
    if (useDark) {
        // Ваша существующая темная палитра
        QPalette darkPalette;
        darkPalette.setColor(QPalette::Window, QColor(53, 53, 53));
        darkPalette.setColor(QPalette::WindowText, Qt::white);
        darkPalette.setColor(QPalette::Base, QColor(25, 25, 25));
        darkPalette.setColor(QPalette::AlternateBase, QColor(53, 53, 53));
        darkPalette.setColor(QPalette::ToolTipBase, Qt::white);
        darkPalette.setColor(QPalette::ToolTipText, Qt::white);
        darkPalette.setColor(QPalette::Text, Qt::white);
        darkPalette.setColor(QPalette::Button, QColor(53, 53, 53));
        darkPalette.setColor(QPalette::ButtonText, Qt::white);
        darkPalette.setColor(QPalette::BrightText, Qt::red);
        darkPalette.setColor(QPalette::Link, QColor(42, 130, 218));
        darkPalette.setColor(QPalette::Highlight, QColor(42, 130, 218));
        darkPalette.setColor(QPalette::HighlightedText, Qt::black);
        qApp->setPalette(darkPalette);
        qDebug() << "Applied Dark Theme.";
    } else {
        // Сбрасываем на стандартную палитру текущего стиля (Fusion)
        qApp->setPalette(QApplication::style()->standardPalette());
        qDebug() << "Applied Light (Standard) Theme.";
        // или так, если setPalette(standardPalette) не сработает как надо
        // QApplication::setPalette(QApplication::style()->standardPalette());
    }
}
int main(int argc, char *argv[])
{
    bool runTests = false;
    int testArgIndex = -1; // Индекс аргумента -test

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-test") == 0) { // Используем strcmp для char*
            runTests = true;
            testArgIndex = i;
            break;
        }
    }

    if (runTests) {
        qDebug() << "!!!!!!!!!!!!!! RUNNING TESTS !!!!!!!!!!!!!!";
        QCoreApplication app(argc, argv); // QCoreApplication все еще может использовать оригинальные argc, argv для своих нужд

        // Создаем новые argc_new и argv_new без флага "-test" для QTest::qExec
        int argc_new = 0;
        std::vector<char*> argv_new_storage; // Хранилище для указателей

        // Первым всегда идет имя программы
        argv_new_storage.push_back(argv[0]);
        argc_new++;

        for (int i = 1; i < argc; ++i) {
            if (i == testArgIndex) { // Пропускаем наш флаг -test
                continue;
            }
            // Добавляем остальные аргументы, которые могут быть для QTest
            argv_new_storage.push_back(argv[i]);
            argc_new++;
        }
        // QTest::qExec ожидает char**, поэтому получаем указатель на данные вектора
        // или создаем массив char* на стеке, если количество аргументов невелико
        char** argv_new = argv_new_storage.data();


        TestDatabase tc;
        // Передаем очищенные аргументы в QTest::qExec
        return QTest::qExec(&tc, argc_new, argv_new);
    }
    else {
        QApplication a(argc, argv);
        QCoreApplication::setOrganizationName("JunTeam");
        QCoreApplication::setApplicationName("OnLib");

        QApplication::setStyle("Fusion");

        QSettings settings;
        bool useDarkTheme = settings.value("ui/useDarkTheme", true).toBool();
        applyTheme(useDarkTheme);

        MyTcpServer server;
        qDebug() << "TCP Server started on port 33333";

        MainWindow mainWindow;
        mainWindow.setWindowTitle("OnLib - Library Management System");
        mainWindow.resize(800, 600);
        mainWindow.show();

        return a.exec();
    }
}
