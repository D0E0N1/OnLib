var searchData=
[
  ['p_5finstance_0',['p_instance',['../class_client.html#a2b768fa77948211e40ce05f027363a9f',1,'Client::p_instance'],['../classdatabase__destroyer.html#a79ad0611fc1e876b6eb755a7255150d7',1,'database_destroyer::p_instance'],['../classdatabase.html#a77030a571acb63483493672e2a32fd33',1,'database::p_instance']]]
];
