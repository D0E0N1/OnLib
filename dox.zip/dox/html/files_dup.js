var files_dup =
[
    [ "client.cpp", "client_8cpp.html", null ],
    [ "client.h", "client_8h.html", "client_8h" ],
    [ "commandhandler.cpp", "commandhandler_8cpp.html", "commandhandler_8cpp" ],
    [ "commandhandler.h", "commandhandler_8h.html", "commandhandler_8h" ],
    [ "database.cpp", "database_8cpp.html", null ],
    [ "database.h", "database_8h.html", "database_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", "mainwindow_8cpp" ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ],
    [ "mytcpserver.cpp", "mytcpserver_8cpp.html", null ],
    [ "mytcpserver.h", "mytcpserver_8h.html", "mytcpserver_8h" ]
];