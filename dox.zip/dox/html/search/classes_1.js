var searchData=
[
  ['database_0',['database',['../classdatabase.html',1,'']]],
  ['database_5fdestroyer_1',['database_destroyer',['../classdatabase__destroyer.html',1,'']]]
];
