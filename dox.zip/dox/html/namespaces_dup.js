var namespaces_dup =
[
    [ "QtCharts", "namespace_qt_charts.html", null ]
];