var mainwindow_8cpp =
[
    [ "applyTheme", "mainwindow_8cpp.html#a7d24d0c1f2058014f103e48e02f15cbb", null ]
];