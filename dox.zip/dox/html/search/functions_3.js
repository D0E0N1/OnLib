var searchData=
[
  ['database_0',['database',['../classdatabase.html#a35ec480ed529a9d092a7ebc5472b767f',1,'database::database()'],['../classdatabase.html#a36c09227a00521cf48c6b672a59959b3',1,'database::database(const database &amp;)']]],
  ['destroy_5finstance_1',['destroy_instance',['../class_client.html#ae6c19f6a75342b7be8673a867bb6e0fd',1,'Client']]],
  ['disconnectfromserver_2',['disconnectFromServer',['../class_client.html#a43ffca98bbbceba21e56b5af97586498',1,'Client']]],
  ['displaychart_3',['displayChart',['../class_main_window.html#a9dbecd01b20e31d40e215a1bbd928e43',1,'MainWindow']]],
  ['displaystatisticsreport_4',['displayStatisticsReport',['../class_main_window.html#a465487518433cc7da63fd766abc758f9',1,'MainWindow']]]
];
