var classdatabase__destroyer =
[
    [ "~database_destroyer", "classdatabase__destroyer.html#aca96543d55d3efa62a79e79d8750c72a", null ],
    [ "initialize", "classdatabase__destroyer.html#ac8b7d07c088aab08a11af3446da63fe8", null ],
    [ "p_instance", "classdatabase__destroyer.html#a79ad0611fc1e876b6eb755a7255150d7", null ]
];