var searchData=
[
  ['database_0',['database',['../classdatabase.html',1,'database'],['../classdatabase.html#a35ec480ed529a9d092a7ebc5472b767f',1,'database::database()'],['../classdatabase.html#a36c09227a00521cf48c6b672a59959b3',1,'database::database(const database &amp;)']]],
  ['database_2ecpp_1',['database.cpp',['../database_8cpp.html',1,'']]],
  ['database_2eh_2',['database.h',['../database_8h.html',1,'']]],
  ['database_5fdestroyer_3',['database_destroyer',['../classdatabase__destroyer.html',1,'database_destroyer'],['../classdatabase.html#a44fb6333d80e1d4e08ca5bba4483f5f3',1,'database::database_destroyer()']]],
  ['destroy_5finstance_4',['destroy_instance',['../class_client.html#ae6c19f6a75342b7be8673a867bb6e0fd',1,'Client']]],
  ['destroyer_5',['destroyer',['../classdatabase.html#a82daa689db1c101e75215e39f6fe0063',1,'database']]],
  ['disconnectfromserver_6',['disconnectFromServer',['../class_client.html#a43ffca98bbbceba21e56b5af97586498',1,'Client']]],
  ['displaychart_7',['displayChart',['../class_main_window.html#a9dbecd01b20e31d40e215a1bbd928e43',1,'MainWindow']]],
  ['displaystatisticsreport_8',['displayStatisticsReport',['../class_main_window.html#a465487518433cc7da63fd766abc758f9',1,'MainWindow']]]
];
