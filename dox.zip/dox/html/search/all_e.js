var searchData=
[
  ['unassignbook_0',['unassignBook',['../class_client.html#af872b0f7d6707d5509241aa5b14a83f4',1,'Client']]],
  ['unassignbookfromuser_1',['unassignBookFromUser',['../classdatabase.html#a8e7e2c30df043af5685dfdbddcb76961',1,'database']]],
  ['unblockuser_2',['unblockUser',['../class_client.html#a8e964b1227167d590c38df4dae617b5f',1,'Client']]],
  ['updatebookannotation_3',['updateBookAnnotation',['../class_client.html#adf124a718f70ec2c81666b68ba0c7447',1,'Client']]],
  ['updatebookinfo_4',['updateBookInfo',['../class_client.html#a0cb2430de1870ea40d76114cbfa53c26',1,'Client::updateBookInfo()'],['../classdatabase.html#ab0e6ec7ae7c8f4ae1113396e6febb38f',1,'database::updateBookInfo()']]],
  ['updateuseremail_5',['updateUserEmail',['../class_client.html#af0529e34d5ba420ed0ce90450de97cbe',1,'Client']]],
  ['userexists_6',['userExists',['../classdatabase.html#add8943b796642d8a20b199d9245ff17e',1,'database']]]
];
