var indexSectionsWithContent =
{
  0: "abcdeghimopqrsuv~",
  1: "cdm",
  2: "q",
  3: "cdm",
  4: "abcdeghimoprsuv~",
  5: "dmp",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Пространства имен",
  3: "Файлы",
  4: "Функции",
  5: "Переменные",
  6: "Друзья"
};

