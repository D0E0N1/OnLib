var searchData=
[
  ['registeruser_0',['registerUser',['../classdatabase.html#ab3c1f2d3020cea543c75cb825c883727',1,'database']]],
  ['resetuserpassword_1',['resetUserPassword',['../class_client.html#ade3756ac0a7f3b674688a9c165a6b622',1,'Client']]]
];
